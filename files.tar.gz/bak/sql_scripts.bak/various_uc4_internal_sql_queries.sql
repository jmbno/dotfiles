-- Show all agent authorizations, by client number
SELECT 
	OH.OH_Name,
	HACL.*
FROM 
	HACL,
	OH
WHERE
	HACL.HACL_OH_Idnr = OH.OH_Idnr 
ORDER BY 
	HACL.HACL_Client;
	
-- Most recent job run, by agent (across all clients)
SELECT 
	OH.OH_Name AS AGENT,
	to_char(max(AH.AH_TimeStamp1), 'yyyy-mm-dd hh24:mi:ss') as MOST_RECENT_RUN_TIMESTAMP
FROM 
	AH,
	OH,
	HOST
WHERE
	((AH.AH_HostDst = OH.OH_Name AND AH.AH_OType <> 'JOBF') OR 
	((AH.AH_HostSrc = OH.OH_Name OR AH.AH_HostDst = OH.OH_Name) AND AH.AH_OType = 'JOBF'))
	AND OH.OH_OType IN ('HOST','HOSTG')
  AND OH_DELETEFLAG = 0
  AND AH.AH_OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')
	AND AH.AH_TimeStamp1 IS NOT NULL
GROUP BY 
	OH.OH_Name
ORDER BY 
	oh.oh_name;
	
-- Most recent job run, by agent/client
SELECT 
	AH.AH_Client AS Client,
	OH.OH_Name AS AGENT,
	to_char(max(AH.AH_TimeStamp1), 'yyyy-mm-dd hh24:mi:ss') as MOST_RECENT_RUN_TIMESTAMP
FROM 
	AH,
	OH,
	HOST
WHERE
	((AH.AH_HostDst = OH.OH_Name AND AH.AH_OType <> 'JOBF') OR 
	((AH.AH_HostSrc = OH.OH_Name OR AH.AH_HostDst = OH.OH_Name) AND AH.AH_OType = 'JOBF'))
  AND OH.OH_OType IN ('HOST','HOSTG')
	AND OH.OH_Idnr = HOST.HOST_OH_Idnr
  AND AH.AH_OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')
	AND AH.AH_TimeStamp1 IS NOT NULL
GROUP BY 
	OH.OH_Name, AH.AH_Client
ORDER BY 
	OH.OH_Name, AH.AH_Client, MOST_RECENT_RUN_TIMESTAMP DESC;
  
-- List of users, by client, last login time
SELECT
  OH.OH_CLIENT,
  OH.OH_NAME,
  USR.USR_FIRSTNAME,
  USR.USR_LASTNAME,
  USR.USR_LASTSESSION
FROM
  OH,
  USR
WHERE
  USR.USR_OH_IDNR = OH.OH_IDNR
ORDER BY OH.OH_CLIENT, USR.USR_LASTSESSION;

-- login object hosts, by client, login name
SELECT
  OH.OH_CLIENT,
  OH.OH_NAME,
  OLC.OLC_HOST
FROM
  OH,
  OLC
WHERE
  OLC.OLC_OH_IDNR = OH.OH_IDNR
  AND OH.OH_DELETEFLAG = 0
ORDER BY
  OH.OH_CLIENT, OH.OH_NAME;

-- Jobs with old or non-existent agent as host
SELECT
  OH.OH_CLIENT,
  OH.OH_NAME,
  JBA.JBA_HOSTDST
FROM
  OH,
  JBA
WHERE
  JBA.JBA_OH_IDNR = OH.OH_IDNR
  AND OH.OH_DELETEFLAG = 0
  AND OH.OH_CLIENT > 0
  AND (
      NOT EXISTS (SELECT 0
                  FROM 
                    OH
                  WHERE 
                    OH.OH_OType IN ('HOST','HOSTG')
                    AND OH_DELETEFLAG = 0
                    AND OH.OH_Name = JBA.JBA_HOSTDST)
      OR JBA.JBA_HOSTDST LIKE '<%'
      )
ORDER BY
  OH.OH_CLIENT, OH.OH_NAME;

-- FTs with old or non-existent agent as host
SELECT
  OH.OH_CLIENT,
  OH.OH_NAME,
  JFA.JFA_HOSTDST,
  JFA.JFA_HOSTSRC
FROM
  OH,
  JFA
WHERE
  JFA.JFA_OH_IDNR = OH.OH_IDNR
  AND OH.OH_DELETEFLAG = 0
  AND OH.OH_CLIENT > 0
  AND (
        (NOT EXISTS (SELECT 0
                    FROM 
                      OH
                    WHERE 
                      OH.OH_OType IN ('HOST','HOSTG')
                      AND OH_DELETEFLAG = 0
                      AND OH.OH_Name = JFA.JFA_HOSTDST)
          OR JFA.JFA_HOSTDST LIKE '<%'
         )
       OR
        (NOT EXISTS (SELECT 0
                    FROM 
                      OH
                    WHERE 
                      OH.OH_OType IN ('HOST','HOSTG')
                      AND OH_DELETEFLAG = 0
                      AND OH.OH_Name = JFA.JFA_HOSTSRC)
          OR JFA.JFA_HOSTSRC LIKE '<%'
        )
      )
ORDER BY
  OH.OH_CLIENT, OH.OH_NAME;
 
-- Events with old or non-existent agent as host
SELECT
  OH.OH_CLIENT,
  OH.OH_NAME,
  OEA.OEA_HOSTDST,
  OEA.OEA_EVENTTYPE
FROM
  OH,
  OEA
WHERE
  OEA.OEA_OH_IDNR = OH.OH_IDNR
  AND OEA.OEA_EVENTTYPE IN ('FT','CN')
  AND OH.OH_DELETEFLAG = 0
  AND OH.OH_CLIENT > 0
  AND (
      NOT EXISTS (SELECT 0
                  FROM 
                    OH
                  WHERE 
                    OH.OH_OType IN ('HOST','HOSTG')
                    AND OH_DELETEFLAG = 0
                    AND OH.OH_NAME = OEA.OEA_HOSTDST)
      OR OEA.OEA_HOSTDST LIKE '<%'
      )
ORDER BY
  OH.OH_CLIENT, OH.OH_NAME;

-- Total count of objects by client  
SELECT 
	OH.OH_Client, 
	count(*)
FROM 
	OH
WHERE 
	OH.OH_DELETEFLAG = 0
GROUP BY
	OH.OH_Client
ORDER BY 
  OH.OH_Client;

SELECT 
	count(*), OH.OH_DELETEFLAG
FROM 
	OH
group by 
  OH.OH_DELETEFLAG
order by
  OH.OH_DELETEFLAG;

select count(OH.OH_CRDATE)
from oh;

SELECT 
  LU.YR,
  count(*)
FROM 
  (SELECT 
	extract(year from OH.OH_CRDATE) as YR from OH) LU
  GROUP BY LU.YR
  ORDER BY LU.YR ASC;
  

-- Total count of objects by year created  
SELECT 
	extract(year from OH.OH_CRDATE), 
	count(*)
FROM 
	OH
GROUP BY
	extract(year from OH.OH_CRDATE)
ORDER BY 
  extract(year from OH.OH_CRDATE) ASC;
  
-- last use of agent - starting from object definition so does not account for jobs with subsequent changes
-- also does some odd selection because of host groups
SELECT
  OH.OH_NAME,
  TO_CHAR(MAX(AHSUB.MRT), 'yyyy-mm-dd hh24:mi:ss')
FROM
  OH,
  (SELECT AH.AH_OH_IDNR, max(AH.AH_TimeStamp1) as MRT
  FROM AH 
  WHERE AH.AH_OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')
  GROUP BY AH.AH_OH_IDNR) AHSUB
WHERE
  OH.OH_OType IN ('HOST','HOSTG')
  AND OH.OH_DELETEFLAG = 0
  AND (
  OH.OH_NAME = (SELECT JBA.JBA_HOSTDST FROM JBA WHERE JBA.JBA_OH_IDNR = AHSUB.AH_OH_IDNR)
  OR
  OH.OH_NAME = (SELECT OEA.OEA_HOSTDST FROM OEA WHERE OEA.OEA_OH_IDNR = AHSUB.AH_OH_IDNR)
  OR
  OH.OH_NAME = (SELECT JFA.JFA_HOSTSRC FROM JFA WHERE JFA.JFA_OH_IDNR = AHSUB.AH_OH_IDNR)
  OR
  OH.OH_NAME = (SELECT JFA.JFA_HOSTDST FROM JFA WHERE JFA.JFA_OH_IDNR = AHSUB.AH_OH_IDNR)
  )
GROUP BY
  OH.OH_NAME
ORDER BY 
  OH.OH_NAME;
  
-- Most recent agent job run datetime, by agent (across all clients)
SELECT AGENT, TO_CHAR(MAX(RUN_TIMESTAMP), 'yyyy-mm-dd hh24:mi:ss')
FROM
(WITH DESTS AS (SELECT  
  AH.AH_HOSTDST as AGENT,
	AH.AH_TimeStamp1 as RUN_TIMESTAMP,
  AH.AH_OTYPE as OTYPE
FROM 
	AH
),
HOSTS AS (SELECT  
  AH.AH_HOSTSRC as AGENT,
	AH.AH_TimeStamp1 as RUN_TIMESTAMP,
  AH.AH_OTYPE as OTYPE
FROM 
	AH
)
SELECT * FROM DESTS
UNION ALL
SELECT * FROM HOSTS)
WHERE
  AGENT IN (SELECT OH.OH_NAME FROM OH WHERE OH.OH_OType IN ('HOST','HOSTG')
  AND OH_DELETEFLAG = 0)
  AND OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')
GROUP BY AGENT
ORDER BY AGENT
;

select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') from dual;

-- agents with no job statistics
SELECT 
	OH.OH_Name,
	TO_CHAR(OH.OH_LastDate, 'yyyy-mm-dd hh24:mi:ss')
FROM 
	OH
WHERE 
 OH.OH_OType IN ('HOST')
	AND OH.OH_Name NOT LIKE '<%'
  AND OH_DELETEFLAG = 0
  AND NOT EXISTS (SELECT 0 FROM AH WHERE AH.AH_HOSTDST = OH.OH_NAME AND AH.AH_OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')) 
  AND NOT EXISTS (SELECT 0 FROM AH WHERE AH.AH_HOSTSRC = OH.OH_NAME AND AH.AH_OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT'))
ORDER BY 
  OH.OH_Name;


-- most recent use by agent, including agents with no job statistics
-- this is quite slow
SELECT AGENT, MRU_DATE
FROM
(SELECT AGENT, TO_CHAR(MAX(RUN_TIMESTAMP), 'yyyy-mm-dd hh24:mi:ss') AS MRU_DATE
FROM
(WITH DESTS AS (SELECT  
  AH.AH_HOSTDST as AGENT,
	AH.AH_TimeStamp1 as RUN_TIMESTAMP,
  AH.AH_OTYPE as OTYPE
FROM 
	AH
),
HOSTS AS (SELECT  
  AH.AH_HOSTSRC as AGENT,
	AH.AH_TimeStamp1 as RUN_TIMESTAMP,
  AH.AH_OTYPE as OTYPE
FROM 
	AH
)
SELECT * FROM DESTS
UNION ALL
SELECT * FROM HOSTS)
WHERE
  AGENT IN (SELECT OH.OH_NAME FROM OH WHERE OH.OH_OType IN ('HOST','HOSTG')
  AND OH_DELETEFLAG = 0)
  AND OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')
GROUP BY AGENT
ORDER BY AGENT)
UNION ALL
(SELECT 
	OH.OH_Name AS AGENT,
	NULL AS MRU_DATE
FROM 
	OH
WHERE 
 OH.OH_OType IN ('HOST')
	AND OH.OH_Name NOT LIKE '<%'
  AND OH_DELETEFLAG = 0
  AND NOT EXISTS (SELECT 0 FROM AH WHERE AH.AH_HOSTDST = OH.OH_NAME AND AH.AH_OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')) 
  AND NOT EXISTS (SELECT 0 FROM AH WHERE AH.AH_HOSTSRC = OH.OH_NAME AND AH.AH_OTYPE IN ('JOBS','JOBF','JOBG','EVNT','!EVNT')))
ORDER BY 
  AGENT
;
  
-- event objects with specified calendar keywords (in table ovp)
select 
  distinct(oh.OH_NAME),
  oh.OH_CLIENT 
from 
  oh, ovp 
where 
  oh.oh_idnr = ovp.ovp_oh_idnr
  and ovp.OVP_CALENAME = 'BATCH_CALENDAR'
  and ovp.OVP_CALEKEYNAME LIKE '1ST_SATURDAY_IN%';

-- as above, usage count only 
select 
  count(1),
  ovp.OVP_CALEKEYNAME 
from 
  ovp 
where 
  ovp.OVP_CALENAME = 'BATCH_CALENDAR'
  and ovp.OVP_CALEKEYNAME LIKE '1ST_SATURDAY_IN%'
group by
  ovp.OVP_CALEKEYNAME;


-- workflow and schedule objects with specified calendar keywords (in table jppc)
select 
  distinct(oh.OH_NAME),
  oh.OH_CLIENT
from 
  oh, jppc 
where 
  oh.oh_idnr = jppc.jppc_oh_idnr
  and jppc.jppc_CALENAME = 'BATCH_CALENDAR'
  and jppc.jppc_CALEKEYNAME LIKE '1ST_SATURDAY_IN%';

-- as above, usage count only  
select 
  count(1),
  jppc.JPPC_CALEKEYNAME
from 
  jppc 
where 
  jppc.jppc_CALENAME = 'BATCH_CALENDAR'
  and jppc.jppc_CALEKEYNAME LIKE '1ST_SATURDAY_IN%'
group by
  jppc.JPPC_CALEKEYNAME;


-- all object usage for an agent
-- change the agent name in the first FROM clause
SELECT
  ag.agent_name,
  oh.OH_CLIENT,
  oh.OH_NAME,
  oh.OH_OTYPE
FROM
  (SELECT 'UC4TOPERATIONS' AS agent_name from dual) ag,
  OH oh
WHERE
  oh.OH_DELETEFLAG = 0
  AND oh.OH_CLIENT > 0
  AND oh.OH_IDNR IN
  ((SELECT JBA.JBA_OH_IDNR FROM JBA WHERE JBA.JBA_HOSTDST = ag.agent_name)
  UNION ALL
  (SELECT OEA.OEA_OH_IDNR FROM OEA WHERE OEA.OEA_HOSTDST = ag.agent_name)
  UNION ALL
  (SELECT JFA.JFA_OH_IDNR FROM JFA WHERE JFA.JFA_HOSTSRC = ag.agent_name)
  UNION ALL
  (SELECT JFA.JFA_OH_IDNR FROM JFA WHERE JFA.JFA_HOSTDST = ag.agent_name)
  UNION ALL
  (SELECT OLC.OLC_OH_IDNR FROM OLC WHERE OLC.OLC_HOST = ag.agent_name)
  )
ORDER BY
  OH.OH_CLIENT, OH.OH_NAME;

-- all object usage for an agent
-- change the agent name in the first WHERE clause
SELECT
  ohhost.OH_NAME AS AGENT_NAME,
  host.HOST_TCPIPADDR AS IP_ADDRESS,
  oh.OH_CLIENT AS CLIENT,
  oh.OH_NAME AS OBJECT_NAME,
  oh.OH_OTYPE AS OBJECT_TYPE,
  OH.OH_LASTDATE AS LAST_USE
FROM
  OH oh,
  HOST host,
  OH ohhost
WHERE
  ohhost.OH_NAME = 'OPERATORSP8'
  AND host.HOST_OH_IDNR = ohhost.OH_IDNR
  AND oh.OH_DELETEFLAG = 0
  AND oh.OH_CLIENT > 0
  AND ohhost.OH_DELETEFLAG = 0
  AND oh.OH_IDNR IN
  ((SELECT JBA.JBA_OH_IDNR FROM JBA WHERE JBA.JBA_HOSTDST = ohhost.OH_NAME)
  UNION ALL
  (SELECT OEA.OEA_OH_IDNR FROM OEA WHERE OEA.OEA_HOSTDST = ohhost.OH_NAME)
  UNION ALL
  (SELECT JFA.JFA_OH_IDNR FROM JFA WHERE JFA.JFA_HOSTSRC = ohhost.OH_NAME)
  UNION ALL
  (SELECT JFA.JFA_OH_IDNR FROM JFA WHERE JFA.JFA_HOSTDST = ohhost.OH_NAME)
  UNION ALL
  (SELECT OLC.OLC_OH_IDNR FROM OLC WHERE OLC.OLC_HOST = ohhost.OH_NAME)
  )
ORDER BY
  ohhost.OH_NAME, host.HOST_TCPIPADDR, OH.OH_CLIENT, OH.OH_NAME;

-- all object usage for an agent by IP address
-- change the IP address in the first WHERE clause
SELECT
  ohhost.OH_NAME AS AGENT_NAME,
  host.HOST_TCPIPADDR AS IP_ADDRESS,
  oh.OH_CLIENT AS CLIENT,
  oh.OH_NAME AS OBJECT_NAME,
  oh.OH_OTYPE AS OBJECT_TYPE
FROM
  OH oh,
  HOST host,
  OH ohhost
WHERE
  host.HOST_TCPIPADDR = '10.70.227.38'
  AND host.HOST_OH_IDNR = ohhost.OH_IDNR
  AND oh.OH_DELETEFLAG = 0
  AND oh.OH_CLIENT > 0
  AND ohhost.OH_DELETEFLAG = 0
  AND oh.OH_IDNR IN
  ((SELECT JBA.JBA_OH_IDNR FROM JBA WHERE JBA.JBA_HOSTDST = ohhost.OH_NAME)
  UNION ALL
  (SELECT OEA.OEA_OH_IDNR FROM OEA WHERE OEA.OEA_HOSTDST = ohhost.OH_NAME)
  UNION ALL
  (SELECT JFA.JFA_OH_IDNR FROM JFA WHERE JFA.JFA_HOSTSRC = ohhost.OH_NAME)
  UNION ALL
  (SELECT JFA.JFA_OH_IDNR FROM JFA WHERE JFA.JFA_HOSTDST = ohhost.OH_NAME)
  UNION ALL
  (SELECT OLC.OLC_OH_IDNR FROM OLC WHERE OLC.OLC_HOST = ohhost.OH_NAME)
  )
ORDER BY
  ohhost.OH_NAME, host.HOST_TCPIPADDR, OH.OH_CLIENT, OH.OH_NAME;

-- select all jobs with a critical flag, order by agent, client, job name, most recent start time
SELECT obj.AGENT_NAME,
       obj.CLIENT,
       obj.OBJECT_NAME,
       TO_CHAR(MAX(ah.AH_TimeStamp1), 'hh24:mi') MOST_RECENT_START_TIME
FROM
  AH ah,
  ((SELECT
    jba.JBA_HOSTDST AS AGENT_NAME,
    oh_jba.OH_CLIENT AS CLIENT,
    oh_jba.OH_NAME AS OBJECT_NAME,
    oh_jba.OH_IDNR AS OBJECT_IDNR
  FROM
    OH oh_jba,
    JBA jba
  WHERE
    jba.JBA_OH_IDNR = oh_jba.OH_IDNR
    AND oh_jba.OH_ARCHIVE2 = 'CRITICAL'
    AND oh_jba.OH_DELETEFLAG = 0)
  UNION
  (SELECT
    oea.oea_HOSTDST AS AGENT_NAME,
    oh_oea.OH_CLIENT AS CLIENT,
    oh_oea.OH_NAME AS OBJECT_NAME,
    oh_oea.OH_IDNR AS OBJECT_IDNR
  FROM
    OH oh_oea,
    OEA oea
  WHERE
    oea.OEA_OH_IDNR = oh_oea.OH_IDNR
    AND oh_oea.OH_ARCHIVE2 = 'CRITICAL'
    AND oh_oea.OH_DELETEFLAG = 0)
  UNION
  (SELECT
    jfa.JFA_HOSTDST AS AGENT_NAME,
    oh_jfa.OH_CLIENT AS CLIENT,
    oh_jfa.OH_NAME AS OJBECT_NAME,
    oh_jfa.OH_IDNR AS OBJECT_IDNR
  FROM
    OH oh_jfa,
    JFA jfa
  WHERE
    jfa.JFA_OH_IDNR = oh_jfa.OH_IDNR
    AND oh_jfa.OH_ARCHIVE2 = 'CRITICAL'
    AND oh_jfa.OH_DELETEFLAG = 0)
  UNION
  (SELECT
    jfa.JFA_HOSTSRC AS AGENT_NAME,
    oh_jfa.OH_CLIENT AS CLIENT,
    oh_jfa.OH_NAME AS OJBECT_NAME,
    oh_jfa.OH_IDNR AS OBJECT_IDNR
  FROM
    OH oh_jfa,
    JFA jfa
  WHERE
    jfa.JFA_OH_IDNR = oh_jfa.OH_IDNR
    AND oh_jfa.OH_ARCHIVE2 = 'CRITICAL'
    AND oh_jfa.OH_DELETEFLAG = 0)
    ) obj
WHERE
  obj.OBJECT_IDNR = ah.AH_OH_IDNR(+)
GROUP BY 
  obj.AGENT_NAME, obj.CLIENT, obj.OBJECT_NAME
ORDER BY
  obj.AGENT_NAME, obj.CLIENT, obj.OBJECT_NAME;
  
-- Calendar keywords from main BATCH_CALENDAR
SELECT
  okb.OKB_NAME
FROM
  OH cal,
  OKB okb
WHERE
  cal.OH_NAME = 'BATCH_CALENDAR'
  AND okb.OKB_OH_IDNR = cal.OH_IDNR
  AND cal.OH_DELETEFLAG = 0;
  
-- Find file transfer jobs with string in the src/dest path
SELECT
  OH.OH_CLIENT,
  OH.OH_NAME,
  JFA.JFA_HOSTDST,
  JFA.JFA_HOSTSRC,
  JFA.JFA_FILENAMEDST,
  JFA.JFA_FILENAMESRC
FROM
  OH,
  JFA
WHERE
  JFA.JFA_OH_IDNR = OH.OH_IDNR
  AND OH.OH_DELETEFLAG = 0
  AND (upper(JFA_FILENAMEDST) LIKE '%TEST%' OR upper(JFA_FILENAMESRC) LIKE '%TEST%');

--------------------------------------------------------------------------------  
-- Queries to identify and update report date that was causing Archiving to fail
-- Change the RT_AH_Idnr to suit

-- View report line records
Select RT_MsgNr, RT_LNR, RT_MsgInsert, RT_TimeStamp
from RT 
where RT_AH_Idnr = '161855297' 
and RT_Type = 'REP' 
order by RT_Lnr ASC;

--Same as above but with long format date displayed
Select RT_LNR, to_char(RT_TimeStamp, 'yyyy-mm-dd hh:MM:ss')
from RT 
where RT_AH_Idnr = '161855297' 
and RT_Type = 'REP' 
order by RT_Lnr ASC;

-- Updates one of the report line records with the date of another
-- Change the RT_Lnr in both the set and where clauses
update RT
set
RT_TIMESTAMP = (Select RT_TimeStamp
                from RT 
                where RT_AH_Idnr = '161855297' 
                and RT_Type = 'REP'
                and RT_Lnr = 7)
where RT_AH_Idnr = '161855297' 
and RT_Type = 'REP'
and RT_Lnr = 8;
--
--------------------------------------------------------------------------------