################################################################################
#   Parses UC4 SAP jobs from an xml export file or files, outputting:
#   Job Name; Login; Report & Variant;
#   
#   Calling this script (files can be named anything, below are just examples):
#
#      From a powershell command prompt:
#       parse_uc4_sap_jobs_xml.ps1 -in_file uc4_export_sap_jobs.xml -out_file uc4_sap_job_details.txt
#       parse_uc4_sap_jobs_xml.ps1 -in_file uc4_export_sap_jobs.xml
#
#      From a .bat file or cmd prompt:
#       powershell parse_uc4_sap_jobs_xml.ps1 -in_file uc4_export_sap_jobs.xml -out_file uc4_sap_job_details.txt
#       powershell parse_uc4_sap_jobs_xml.ps1 -in_file uc4_export_sap_jobs.xml
#
#      From windows explorer, right-click and select 'Run with PowerShell':
#       The script will prompt for the input file name.
#
#      From windows explorer, using a shortcut from a different location:
#       Create a shortcut from the original file (right-click, create shortcut);
#       Copy the shortcut to the desired location (for example, the folder where you export uc4 xml files to);
#       Right-click on the shortcut in the new folder and under properties, change 'Start In' to the new folder path;
#       To run, right-click and select 'Run with PowerShell' as per the previous example.
#
#      Paths should be provided relative to either the script or the input/output files.
#      The most straightforward way is if everything is in the same directory.      
#
#   Wildcard * is allowed for multiple input files;
#   Output file defaults to uc4_sap_job_details.txt if not specified.
#
###############################################################################

# parse input parameters
[CmdletBinding()]
param (
	[Parameter(Mandatory=$True, Position=1)] 
    [string]$in_file,
	
	[Parameter(Mandatory=$False)]
	[string]$out_file = "uc4_sap_job_details.txt"
 )


echo "Loading..." ""
echo "Input will be read from file(s): $($in_file)" ""
echo "Output will be written to file: $($out_file)" ""

# remove old output file if it exists
if(test-path $out_file) {
	rm $out_file
}

# check the specified input file(s) exist, exit otherwise
if(!(test-path $in_file)) {
	echo "File(s) $($in_file) could not be found, exiting..."
	Start-Sleep -s 5
	exit
}

# get the list of input files
$files = get-childitem $in_file

foreach ($file in $files) {
	echo "...reading file: $($file)"
	[xml]$xml = gc $file 
	# uc4 xml export files always have <uc-export> as the opening tag
	# <jobs_r3> is the tag for SAP jobs
	$jobs = $xml.'uc-export'.jobs_r3
	
	# go through each SAP job and extract the report & variant which is in the
    # <script><mscri> tag as comment data - '#cdata-section' is how powershell
    # handles it. Output the job name and report/variant data to $out_file
	foreach ($job in $jobs) {
		$login = $job.attr_jobs.login;
		$rpt_var = $job.script.mscri.'#cdata-section'.replace("`n","");
		write-output "$($job.name); $($login); $($rpt_var);" | out-file $out_file -append
	}
} 

echo "" "Done, exiting."
Start-Sleep -s 2
