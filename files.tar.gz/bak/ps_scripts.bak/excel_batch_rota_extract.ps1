function Remove-ComObject { 
 [CmdletBinding()] 
 param() 
 end { 
  Start-Sleep -Milliseconds 500 
  [Management.Automation.ScopedItemOptions]$scopedOpt = 'ReadOnly, Constant' 
  Get-Variable -Scope 1 | Where-Object { 
   $_.Value.pstypenames -contains 'System.__ComObject' -and -not ($scopedOpt -band $_.Options) 
  } | Remove-Variable -Scope 1 -Verbose:([Bool]$PSBoundParameters['Verbose'].IsPresent) 
  [GC]::Collect() 
 } 
  
 <# 
 .Synopsis 
     Releases all <__ComObject> objects in the caller scope. 
 .Description 
     Releases all <__ComObject> objects in the caller scope, except for those that are Read-Only or Constant. 
 .Example 
     Remove-ComObject -Verbose 
     Description 
     =========== 
     Releases <__ComObject> objects in the caller scope and displays the released COM objects' variable names. 
 .Inputs 
     None 
 .Outputs 
     None 
 .Notes 
     Name:      Remove-ComObject 
     Author:    Robert Robelo 
     LastEdit:  01/13/2010 19:14 
 #> 
}

# This is a common function i am using which will release excel objects

function Release-Ref ($ref) 
{
([System.Runtime.InteropServices.Marshal]::ReleaseComObject( [System.__ComObject]$ref) -gt 0)

[System.GC]::Collect()

[System.GC]::WaitForPendingFinalizers()
}

# Creating excel object

$objExcel = new-object -comobject excel.application 

#$objExcel.Visible = $True 

 # Directory location where we have our excel files

$ExcelFilesLocation = "P:\docs\"

 # Open our excel file

$UserWorkBook = $objExcel.Workbooks.Open($ExcelFilesLocation + "standby_rota_2013_copy.xls") 

# Get the worksheet named 'Rota 2013'

$UserWorksheet = $UserWorkBook.Worksheets | where { $_.name -eq 'Rota 2013' }

$today = date
# Start at column 2 for the weekly date period check - index is incremented as
# first step in do-while loop
$index = 1

do {
	$index++
	# Make a period start date from the first entry in the current DD MMM - DD MMM cell
	$checkDate = date ($UserWorksheet.Cells.Item(4, $index).Value().split("-")[0] + " 2013")
}
while ( $today -gt $checkDate.addDays(7) ) # Add 7 days 

$currentPeriodColumn = $index

# Start at row 6 for on-call details 
$intRow = 6
$index = 0

#init empty array for contact data
$contacts = @()

Do {

	# Reading the first column of the current row
	
	$dept = $UserWorksheet.Cells.Item($intRow, 1).Value()
	$contactCell = $UserWorksheet.Cells.Item($intRow, $currentPeriodColumn)
	
	if( ! $contactCell.comment ) {
		$contacts += @($dept + "," + $contactCell.Value())
	} 
	else {
		$contacts += @($dept + "," + $contactCell.Value() + "," + $contactCell.comment.text())
	}

	$intRow++
	$index++

} While ($intRow -lt 22)
# Stop after row 21, which is the last with contact data

$contacts

# Exiting the excel object

$UserWorkBook.Close($false)
$objExcel.Quit()
Remove-ComObject

#Remove-ComObject -Verbose


#Release all the objects used above
#$a = Release-Ref($UserWorksheet)
#$a = Release-Ref($UserWorkBook) 
#$a = Release-Ref($objExcel)
