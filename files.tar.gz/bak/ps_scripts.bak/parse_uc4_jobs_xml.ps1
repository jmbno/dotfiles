################################################################################
#
#  Parses Windows, UNIX, SAP and File Transfer UC4 jobs from an xml export file
#  or files, outputting various job detail fields:
#
#  Windows:
#  Job Name; Login; Working Directory; Process Tab Commands;
#
#  UNIX:
#  Job Name; Login; Single Command (if it exists); Process Tab Commands;
#
#  SAP:
#  Job Name; Login; Report & Variant;
#
#  File Transfer:
#  Job Name; Source Host; Source Login; Source Filepath; Destination Host; 
#  Destination Login; Destination Filepath; Erase Source on Transfer (Yes/No);
#
#  New lines in the process tab / script are replaced with a <nl> placeholder.
#
#  Calling this script (input/output files can be named anything, below are 
#  just examples):
#
#    From a .bat file, cmd prompt or powershell prompt:
#      powershell parse_uc4_jobs_xml.ps1 -in_file in_file.xml -out_file out_file.txt
#      powershell parse_uc4_jobs_xml.ps1 -in_file in_file.xml
#
#    From windows explorer, right-click and select 'Run with PowerShell':
#      The script will prompt for the input file name.
#
#    From windows explorer, using a shortcut from a different location:
#     Create a shortcut from the original file (right-click, create shortcut);
#     Copy the shortcut to the desired location (for example, the folder where
#     you usually save uc4 xml export files);
#     Right-click on the shortcut in the new folder and under properties, 
#     change 'Start In' to the new folder path;
#     To run, right-click and select 'Run with PowerShell' as per the previous 
#     example.
#
#    Paths should be relative to either the script or the input/output files.
#    The most straightforward way is if everything is in the same directory.      
#
#    Wildcard * is allowed for multiple input files.
#    Output file defaults to uc4_job_details.txt if not specified.
#
###############################################################################

# parse input parameters
[CmdletBinding()]
param (
	[Parameter(Mandatory=$True, Position=1)] 
    [string]$in_file,
	
	[Parameter(Mandatory=$False)]
	[string]$out_file = "uc4_job_details.txt"
)


echo "Loading..." ""
echo "Input will be read from file(s): $($in_file)" ""
echo "Output will be written to file: $($out_file)" ""

# remove old output file if it exists
if(test-path $out_file) {
	rm $out_file
}

# check the specified input file(s) exist, exit otherwise
if(!(test-path $in_file)) {
	echo "File(s) $($in_file) could not be found, exiting..."
	Start-Sleep -s 5
	exit
}

# get the list of input files
$files = get-childitem $in_file

# go through each input file and build up each set of job types
# doing it like this means each type can be in its own section in
# the output file
foreach ($file in $files) {
	echo "...reading file: $($file)"
	[xml]$xml = gc $file 
	# uc4 xml export files always have <uc-export> as the opening tag
	# <JOBS_WINDOWS> is the tag for Windows jobs
	# <JOBS_UNIX> is the tag for UNIX jobs
	# <jobs_r3> is the tag for SAP jobs
	$winjobs = $winjobs + $xml.'uc-export'.jobs_windows
	$unixjobs = $unixjobs + $xml.'uc-export'.jobs_unix
	$sapjobs = $sapjobs + $xml.'uc-export'.jobs_r3
	$ftjobs = $ftjobs + $xml.'uc-export'.jobf
}
	
# Go through each job set and extract fields.
# Output data to $out_file.
# Windows
write-output ("[WINDOWS JOBS]`n" +
			"Job Name; Login; Working Directory; Process Tab Commands;") |
			out-file $out_file -append
if ($winjobs -ne $null) {
	foreach ($job in $winjobs) {
		$login = $job.attr_jobs.login;
		$workdir = $job.attr_windows.workingdirectory;
		$process = $job.script.mscri.'#cdata-section'.replace("`n","<nl>");
		$process = ('"' + $process + '"');
		write-output "$($job.name); $($login); $($workdir); $($process);" | 
			out-file $out_file -append
	}
}
# UNIX
write-output ("[UNIX JOBS]`n" +
			"Job Name; Login; Single Command; Process Tab Commands;") |
			out-file $out_file -append
if ($unixjobs -ne $null) {
	foreach ($job in $unixjobs) {
		$login = $job.attr_jobs.login;
		$command = $job.attr_jobs.com;
		$process = $job.script.mscri.'#cdata-section'.replace("`n","<nl>");
		$process = ('"' + $process + '"');
		write-output "$($job.name); $($login); $($command); $($process);" | 
			out-file $out_file -append
	} 
}
# SAP
write-output ("[SAP JOBS]`n" +
			"Job Name; Login; Report and Variant;") | 
			out-file $out_file -append
if ($sapjobs -ne $null) {
	foreach ($job in $sapjobs) {
		$login = $job.attr_jobs.login;
		$rpt_var = $job.script.mscri.'#cdata-section'.replace("`n","");
		write-output "$($job.name); $($login); $($rpt_var);" | 
			out-file $out_file -append
	}
}

# File Transfers
write-output ("[FILE TRANSFER JOBS]`n" +
			"Job Name; Source Host; Source Login; Source Filepath; " +
			"Destination Host; Destination Login; Destination Filepath; " +
			"Erase Source on Transfer (Yes/No);") | out-file $out_file -append
if ($ftjobs -ne $null) {
	foreach ($job in $ftjobs) {
		$srchost = $job.jobf.hostsrc.replace("|HOST","");
		$srclogin = $job.jobf.loginsrc;
		$srcfile = $job.jobf.filenamesrc;
		$dsthost = $job.jobf.hostdst.replace("|HOST","");
		$dstlogin = $job.jobf.logindst;
		$dstfile = $job.jobf.filenamedst;
		$erase = $(if ($job.jobf.erase -eq 1) {"Yes"} else {"No"});
		write-output ("$($job.name); $($srchost); $($srclogin); $($srcfile); " +
					 "$($dsthost); $($dstlogin); $($dstfile); $($erase);") | 
			out-file $out_file -append
	} 
}
echo "" "Done, exiting."
Start-Sleep -s 2
