###############################################################################
#
# Uptime Report: Get details of the last reboot(s) for a list of servers.
#
# Input:  The list of servers is read from the data section at the end of this
#         file.
#         A list of text replacements for server names in also included in the
#         data section.
# 
# Output: Details of reboot times for the checked servers. Three output files 
#         are produced - (1)log, (2)report and (3)error.
#         (1) The log file contains server name, time since last reboot (uptime)
#         and last reboot time. If the reboot was within a specified time period 
#         (currently: after 07.00 on the previous day), then additional details 
#         of user, action, reason and comment are included. If there was more 
#         than one reboot within the check period, the additional records are 
#         also output. Also logged are servers where no reboot details could be
#         retrieved.
#         (2) The report file contains the full reboot details of servers where
#         the last reboot is within the specified time period, and the list of
#         servers where no reboot details could be retrieved. The report file 
#         is emailed to the Enterprise Application Services EntOps mailbox.
#         (3) The error file records the exception details for servers where
#         reboot details were not retrieved.
#
# Author: C. Hamilton (conor.hamilton@esb.ie)
#
# Date:   2014-12-09
#
# Revisions: 
#         2015-02-13 (CH) Capture all reboots within check period, not just
#                         most recent.
#         2015-04-13 (CH) Add generation of HTML files for report, log and 
#                         error files. Include links to same in report email.
#
###############################################################################

###############################################################################
#
# GLOBAL VARIABLES SECTION
#
###############################################################################

# Full path & file name of this script file
$thisfile = $MyInvocation.MyCommand.Path

# Path of this script file
$thispath = Split-Path -Parent -Path $thisfile

# Output files
$logFile = "$thispath\uptime.log"
$errFile = "$thispath\uptime.err"
$rptFile = "$thispath\uptime_report_$((date).toString('yyyy-MM-dd')).txt"

# Basic html pages
$urlBase = "http://"
$logFileHTML = "uptime_full_log.html"
$rptFileHTML = "uptime_report.html"
$errFileHTML = "uptime_error_log.html"

# Check from 07.00(AM) of the previous day
$checkDateTime=[DateTime]::Today.AddDays(-1).AddHours(7)

###############################################################################
#
# FUNCTIONS SECTION
#
###############################################################################

# File housekeeping - remove old files and set up headers
function Initialise_Files 
{
	# remove old files
	if (test-path $logFile) {rm $logFile}
	if (test-path $errFile) {rm $errFile}
	if (test-path $rptFile) {rm $rptFile}

	# Get the current date/time for file headers
	$now = $(date)
	$nowdt = $now.toString('dddd, dd/MM/yyyy')
	$nowtm = $now.toString('HH:mm:ss')

	# Log/error file headers
	echo "Uptime log file" "" "${nowdt}" "" "${nowtm}" "" >> $logFile
	echo "Uptime error file" "" "${nowdt}" "" "${nowtm}" "" >> $errFile

	# Main report header
	echo @"
----------------------------------------------
-    DAILY UPTIME REPORT		     -
----------------------------------------------

${nowdt}

${nowtm}

"@ >> $rptFile
}

# Get the list of servers to check as an array.
function Get_Server_Names {
	# Get the server list from data section at end of this file by finding uptime 
	# at line start then replacing everything but the server name.
	# Line should be in the format: uptime: server-name
	$servers = (Select-String $thisfile -pattern '^uptime:') -replace '.*uptime:\s+','' -replace '\s+.*',''
	return $servers
}

# Get the list of text replacement pairs as a dictionary object.
function Get_Text_Replacements {
	$replacements = @{}
	(Select-String $thisfile -pattern '^replace:') -replace '.*replace:\s+','' | foreach {
		# Splitting on " gives 4 items, the text_to_replace and replacement text
		# are the 2nd and 4th items (so index 1 and 3, array is 0-indexed)
		$values = $_.split('"')
		$replacements.add($values[1], $values[3])
	}
	return $replacements
}


# Only return the first few objects from a scriptblock, determined by date.
# This is done by processing the returned objects one by one, instead of 
# waiting for all to be returned before checking them. Waiting for the full
# list to be returned first slows processing considerably.
# (The 'continue' statement is the important part of this).
function Get_Last_Reboot_Details_Single_Server_By_Date {
	param(
		[Parameter(ValueFromPipeline=$false,Position=0,Mandatory=$true)]
		[scriptblock]$scriptBlock
	)
	
	Invoke-Command -ScriptBlock $scriptBlock | 
	ForEach-Object `
		-Begin { 
		} `
		-Process {
		
			if($_) {
				# If the reboot date/time is before checkDateTime, return from the function
				if($_.ConvertToDateTime($_.TimeGenerated) -lt $checkDateTime) {
					continue
				}
				$_
			}
			else {
				$NULL
				continue
			}
		}
}

# Get the last reboot details for a single server
function Get_Last_Reboot_Details_Single_Server {
	param(
		[Parameter(ValueFromPipeline=$false,Position=0,Mandatory=$true)]
		[String]$computerName
	)

	BEGIN {
		# initialise the result array
		$results=@()
	}
	PROCESS {
		foreach ($computer in $computername) {
			# this is the main script command for getting the full reboot details of a server.
			# eventCode 1074 is a reboot
			#$sb = {Get-WmiObject -ComputerName $computerName -Query "SELECT * FROM Win32_NTLogEvent WHERE Logfile='System' AND EventCode=1074 AND TimeGenerated>='20150205'"}
			$sb = {Get-WmiObject -ComputerName $computerName -Query "SELECT * FROM Win32_NTLogEvent WHERE Logfile='System' AND EventCode=1074"}
			
			# (try to) pass the command to the first pipeline object function
			try{
				get_last_reboot_details_single_server_by_date -scriptblock $sb -ErrorAction "stop" | foreach {$results+=$_}
			}
			catch [System.Exception]{
				write-error "${computer} reboot details could not be retrieved"
				write-error $_
			}
		}
	}
	END {
		# return the results
		$results
	}
}

# Get the last reboot details for a list of servers
# and output to log/report/error files
function Get_Last_Reboot_Details {
	[CmdletBinding()]
	param(
		[Parameter(ValueFromPipeline=$true,Position=0,Mandatory=$true)]
		[String[]]$computerName,
		[Parameter(ValueFromPipeline=$false,Position=1,Mandatory=$false)]
		[System.Collections.Hashtable]$replacements=@{}
	)
	
	BEGIN {
		# Initialise variables for results
		$count=0
		$results = New-Object System.Collections.Specialized.OrderedDictionary
		$failures = @()
	}
	PROCESS {
		# Go through the list of servers passed to this function
		foreach ($computer in $computername) {
			# Notify every 25 checks to verbose
			if(($count % 25) -eq 0) { 
				write-verbose "Checked ${count} / $($computername.count) Servers"
			}
			
			# First just try and get the last reboot time
			$gwmi=""
			try{
				$gwmi = gwmi -class win32_operatingsystem -computer $computer -ErrorAction "stop"
			}
			catch [System.Exception]{
				write-error "${computer} reboot details could not be retrieved"
				write-error $_
			}

			# If details were retrieved
			if ($gwmi) {
				# Calculate the boottime / uptime
				$boottime = $gwmi.convertToDateTime($gwmi.lastBootUpTime)
				$uptime=new-timespan -start $boottime 
				
				# Create a dictionary for the details
				$details = [System.Collections.ArrayList]@()
				
				# Check if the reboot was within recent time period
				if ($boottime -gt $checkDateTime) {
					# Try and get the full reboot details
					$reboots = Get_Last_Reboot_Details_Single_Server -computername $computer
					
					# If found, add values to the details dictionary
					foreach ($reboot in $reboots) {
						# Calculate new boot/up times from the actual reboot detail
						$boottime = $reboot.ConvertToDateTime($reboot.TimeGenerated)
						$uptime = new-timespan -start $boottime
						# Add to a dictionary object
						$detail = @{"uptime"=$uptime; 
									"boottime"=$boottime;
									"user"=$reboot.insertionstrings[6];
									"action"=$reboot.InsertionStrings[4];
									"reason"=$reboot.InsertionStrings[2];
									"comment"=$reboot.InsertionStrings[5];
									};
						# Add to the details array. ([void] ignores the int return of .add())
						[void]$details.add($detail);
					}
				}
				# Add a basic detail (boot/uptime) if no detailed reboots were retrieved
				if($details.count -eq 0) {
					[void]$details.add(@{"uptime"=$uptime; "boottime"=$boottime})
				}
				# Add the full results for a server	
				$results.add($computer, $details)
			}
			else {
				# Otherwise add to failures list
				$failures+=$computer
			}
			$count++
		}
	}
	END {
			return $results, $failures
		}
}

# Process results and output to logs
function Write_Files {
	[CmdletBinding()]
	param(
		[Parameter(ValueFromPipeline=$false,Position=0,Mandatory=$true)]
		[System.Collections.Specialized.OrderedDictionary]$rebootResults,
		[Parameter(ValueFromPipeline=$false,Position=1,Mandatory=$true)]
		[String[]]$failures,
		[Parameter(ValueFromPipeline=$false,Position=2,Mandatory=$false)]
		[System.Collections.Hashtable]$replacements=@{}
	)
	$count = $rebootResults.count + $failures.count
	# Notify the number of results to logs
	$msg = "Checked reboots occurring after $checkDateTime for $count Servers, got $($rebootResults.count) OK and $($failures.count) undetermined response(s)"
	echo $msg "" >> $logfile
	echo $msg "" >> $rptfile
	
	# Notify number of results and name of output files to verbose stdout
	write-verbose $msg
	write-verbose "Report file: $rptfile"
	write-verbose "Log file:    $logfile"
	write-verbose "Error file:  $errfile"
			
	# Header for recent reboot details in main report
	echo "--------------------------------------------" >> $rptfile
	echo " Recent Reboot Details:" >> $rptfile
	echo "--------------------------------------------" >> $rptfile

	# Field names for log file
	echo "Server; Uptime; Last Boot Time; User; Action; Reason; Comment;" >> $logfile
	
	# Track the number of records output to report
	$rebootsForReport = 0
	
	# Process input records - should be dictionary (hashtable) of records 
	# containing:
	#   key: ServerName  
	#   value: An ArrayList of dictionaries of reboot details, for example:
	#				[{"uptime"="..";"boottime'".."; etc..;"}, {..}, {..}]
	foreach ($record in $rebootResults.getEnumerator()) {
		$server = $record.key
		
		$serverStr = $server
		if ($replacements[$server]) {$serverStr = $replacements[$server]}
		$details = $record.value
		
		foreach ($detail in $details) {
			$uptime = $detail["uptime"]
			$boottime = $detail["boottime"]
			$boottimeStr = $boottime.ToString('yyyy-MM-dd HH:mm:ss')
			$uptimeStr = ("{0} Days, {1} Hrs, {2} Mins" -f $uptime.Days, $uptime.Hours, $uptime.Minutes)
						
			# Check if the reboot was within recent time period
			if ($boottime -gt $checkDateTime) {
				$user = $detail["user"]
				$action = $detail["action"]
				$reason = $detail["reason"]
				$comment = $detail["comment"]
			
				# Output field headers for first record
				if ($rebootsForReport -eq 0) {
					echo "Server; Uptime; Last Boot Time; User; Action; Reason; Comment;" >> $rptfile
				}
				$rebootsForReport++
				# Output to report and log files
				echo "$serverStr; $uptimeStr; $boottimeStr; $user; $action; $reason; $comment;" >> $rptfile
				echo "$serverStr; $uptimeStr; $boottimeStr; $user; $action; $reason; $comment;" >> $logfile
			}
			else {
				# Output to log file for a non-recent reboot
				echo "$serverStr; $uptimeStr; $boottimeStr;" >> $logfile
			}
		}
	}
	# Add message if no recent reboots were found		
	if ($rebootsForReport -eq 0) {
		echo "No recent reboots were found." >> $rptfile
	}
	
	# Log file info
	echo "" "See log file ${logfile} for reboot details of all checked servers." "" "" >> $rptfile
	
	# Header for details not retrieved
	echo "--------------------------------------------" >> $rptfile
	echo " Reboot Details could not be retrieved for:" >> $rptfile
	echo "--------------------------------------------" >> $rptfile
	
	# Write failures
	foreach ($computer in $failures) {
		echo "${computer}; reboot details could not be retrieved;" >> $logfile
		echo "${computer}" >> $rptfile
	}
	
	# Failures info
	if ($failures.count -eq 0) {
		echo "Reboot details were retrieved successfully for all checked servers." >> $rptfile
	}
	else {		
		echo "" "See error file ${errfile} for error details." "" "" >> $rptfile
	}
}

function Write_HTML_Files
{
	$style = "<style>BODY{font-family: 'Lucida Console', Monaco, monospace; font-size: 80%;}</style>"
	# Have to use new psobjects as convertto-html won't convert plain strings
	gc $rptfile | %  {New-object psobject -property @{" "=$_}} | select " " | ConvertTo-Html -Head "${style}<title>Uptime Report</title>" > $rptFileHTML
	gc $logfile | %  {New-object psobject -property @{" "=$_}} | select " " | ConvertTo-Html -Head "${style}<title>Uptime Full Log</title>" > $logFileHTML
	gc $errfile | %  {New-object psobject -property @{" "=$_}} | select " " | ConvertTo-Html -Head "${style}<title>Uptime Error Log</title>" > $errFileHTML
}

# Main function - get the server list and text replacements, retrieve reboot
# details, write files and then send report email
function Main {
		
	# Get server name list (array) and pairs of text replacements list (dictionary)
	$servers = Get_Server_Names
	$replacements = Get_Text_Replacements

	# Get reboot details
	$results, $failures = Get_Last_Reboot_Details -computerName $servers -verbose
	
	# Output to report and log files
	Write_Files -rebootresults $results -failures $failures -replacements $replacements -verbose
	
	# Create basic HTML versions of files
	Write_HTML_Files
	
	# Send report via email
	$mailparams = @{ 
		To = "";
		Cc = "";
		From = "";
		Subject = "New! Daily Uptime Report from ";
		Body = "Please find attached the Daily Uptime Report.";
		Attachments = @("$rptfile");
		SMTP = "";
	}
	# Check if backup file exists, then add to attachments.
	# This file is created by a different process, but gets included with 
	# the uptime report mail.
	$backupFile = ""
	if (test-path $backupFile) {
		$mailparams["Attachments"] += "$backupfile";
		# Update the subject & body too..
		$mailparams["Subject"] = "New! Daily Uptime Daily Uptime and Brightstor Reports from ";
		$mailparams["Body"] = "Please find attached the Daily Uptime and Daily Backup* Reports.";
	}
	
	# Add links for report/error details
	$mailparams["Body"] += "`r`n`r`nUptime Links:";
	$mailparams["Body"] += "`r`nReport`t $urlBase/$rptFileHTML";
	$mailparams["Body"] += "`r`nFull Log`t $urlBase/$logFileHTML";
	$mailparams["Body"] += "`r`nErrors`t $urlBase/$errFileHTML";
	
	send-mailmessage @mailparams  	
}

###############################################################################
#
# MAIN PROCESSING SECTION
# 
###############################################################################
# Start time
echo "Started processing at $(date)" ".."
echo "Retrieving details of reboots after ${checkDateTime}" ".."
# Set up output files
Initialise_Files

# Run main function, outputting any errors to error file
Main 2>$errfile

# End time
echo ".." "Finished processing at $(date)"

# Exit with success
# Nothing after this command will be executed, so data section is included after it
exit 0


###############################################################################
#
# DATA SECTION
# 
###############################################################################


###############################################################################
#
# List of Servers to Check
#
# Format for including a server is: 
# uptime: server
#
# To exclude a server, just put rem at the start of the line, i.e.: 
# rem uptime: server
#
# List is enclosed in @" "@ to ensure powershell doesn't try to parse it.
#
###############################################################################
@"
uptime: NOTAREALSERVER
"@

###############################################################################
#
# Replacements Section
#
# Format for replacements is: 
# replace: "text_to_replace" "replacement_text"
#
# To exclude a line, just put rem at the start of the line, i.e.: 
# rem replace: "text_to_replace" "replacement_text"
#
# List is enclosed in @" "@ to ensure powershell doesn't try to parse it.
#
###############################################################################
@"
replace: "servername" "**Some replacement text**  servername"
"@
