#!/bin/bash

#######################
#
# remove one line from a set of two identical consecutive lines
# 
# usage: ./$0 pattern file
# or read from stdin e.g.: cat file | ./$0 pattern
#
#######################

line="$1"
input_file="${2:-/dev/stdin}"

sed "/^$line$/ {
N
s/^$line\n$line$/$line/
}" $input_file

