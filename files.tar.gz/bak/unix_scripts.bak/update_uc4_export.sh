#!/bin/bash
# $1 should be a uc4 xml export file 
# $2 is the output file
# $3 is a file of tab-separated changes for sed

src=$1
dst=$2
changefile=$3

cp $src $dst

OIFS=$IFS
IFS=$'\t'

while read changes; do
  set -- $changes
  sed -i "s/$1/$2/g" $dst
done < $changefile

IFS=$OIFS
