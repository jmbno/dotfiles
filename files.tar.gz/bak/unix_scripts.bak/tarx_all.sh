#!/bin/bash
# tarx_all.sh
# extract multiple tar files ...
echo $BASH_SOURCE

# Get base name of this script
me=${0##*/}                 # Script name

# Get absolute directory of this script
mydir=$(realpath $0)        # Script location
mydir=${mydir%/*}           # Get directory name
mydir=${mydir:-/}           # Special case for root directory
mydir=$(cd $mydir; pwd)     # Absolute directory

E_BADARGS=85

if [ ! -n "$1" ]
then
  echo "Usage: `basename $0` argument1 argument2 etc."
  exit $E_BADARGS
fi  

echo

index=1          # Initialize count.

for arg in "$*"  # Doesn't work properly if "$*" isn't quoted.
do
  echo "Extracting files: $arg"
  let "index+=1"
done             # $* sees all arguments as single word. 

for file in "$@"
do
  echo "Extracting file: $file"	
  tar -xvf $file
done  

exit 0
 
