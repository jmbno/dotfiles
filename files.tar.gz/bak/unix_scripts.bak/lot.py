#!/usr/bin/env python

import sys
import argparse
from random import sample
import os
import urllib2
from bs4 import BeautifulSoup

def printresults():
    page = urllib2.urlopen('http://www.rte.ie/lotto/euromillions.html')
    #page = urllib2.urlopen('file://' + os.path.abspath('../tmp/em.html'))
    
    soup = BeautifulSoup(page)
    
    date = soup.body.find('div', class_='date archive').text.replace('Euro Millions r','R')
    #maind = soup.body.find('div', class_='col1 rte_gr_8')
    maind = soup.body.find('section', class_='group euro-results col1')
    numbersd = maind.find_all('div', class_='redball ball')
    bonusd = maind.find_all('div', class_='bonus')
    winnersd = maind.find('ul', class_='winners')
    
    numbersl = []
    for n in numbersd:
        numbersl.append(str(n.text))
    
    bonusl = []
    for b in bonusd:
        bonusl.append(str(b.text))
    
    winnersl = []
    for li in winnersd.find_all('li'):
        vals = []
        for span in li.find_all('span'):
            vals.append(span.text)
        winnersl.append(vals)
     
    print '\n', date
    print '\nNumbers:\n', numbersl, bonusl, '\n'
    
    col_widths = []
    for n in range(len(winnersl[0])):
        col_widths.append(max([len(row[n]) for row in winnersl]))
    
    for row in winnersl:
        for n in range(len(col_widths)):
            print row[n].ljust(col_widths[n] + 1).encode('utf-8'),
        print


def printlines(n):
    numlines = n
    print str(numlines) + ' lines to do:'

    for x in xrange(numlines):
        ln = sorted(sample(range(1,51), 5))
        bn = sorted(sample(range(1,12), 2))
        print ln, bn

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-g', metavar='N', nargs='?', const=2, type=int, help='generate %(metavar)s number of lines to do, default is %(const)s')
    parser.add_argument('-r', action='store_true', help='Print results of most recent draw')
    args = parser.parse_args()
    if args.g:
        printlines(args.g) 
    elif args.r:
        printresults() 
    else:
        parser.print_help()

    exit(0)

