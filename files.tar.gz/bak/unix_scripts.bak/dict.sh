#!/bin/bash -
#
# dict word_to_find
#
  input_word_list="$1"

dictionary_file="$HOME/dicts/websters_1913"
if [ -e "$dictionary_file" ]
then
echo "$input_word_list" | tr -s ' ' '\n' | sort | uniq | tr a-z A-Z |
gawk -- ' NR==FNR {
  wordlist[FNR, 1] = $0; wordlist[FNR, 2] = "0"; maxrc=FNR
}
NR>FNR {
 for (rc = 1; rc <= maxrc; rc++)
# Uncomment the following program line while commenting the == line AND set FS="\n" after the RS declaration on last line if you want matches to compound or similar words instead of exact matches.
# Note that dictionary has the form ABIME ABYME on same line for variant spellings of an entry.
# if (match($2, wordlist[rc, 1]))
  if ($1 == wordlist[rc, 1])
  {
   print $0; wordlist[rc, 2] = "1"
  }
}
END {
print " "
print "Any words not found are listed below..."
for (rc = 1; rc <= maxrc; rc++)
if (wordlist[rc, 2] == "0")
  print wordlist[rc, 1]
}' - RS="<<entry>>" "$dictionary_file"
else
  echo "missing/incorrect dictionary file"
fi

