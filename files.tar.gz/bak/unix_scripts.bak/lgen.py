#!/usr/bin/env python

import sys
from random import sample

if __name__ == '__main__':
    if len(sys.argv) <= 1:
        lines = 2
    else:
        lines = int(sys.argv[1])

    print str(lines) + ' lines to do:'

    for x in xrange(lines):
        ln = sorted(sample(range(1, 51), 5))
        bn = sorted(sample(range(1, 12), 2))
        print ln, bn

