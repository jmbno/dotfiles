#!/usr/bin/env python
################################################################################
#   Parses UC4 Windows jobs from an xml export, outputting:
#   Job Name; Login; Working Directory; Process Tab Commands (i.e. the script);
#
#   New lines in the process tab / script are replaced with a <nl> placeholder.
################################################################################

from xml.dom import minidom
import sys

if len(sys.argv) <= 1:
    print 'Need a file to process, exiting'
    exit() 
else:
    filename = sys.argv[1]

xmldoc = minidom.parse(filename)

jobs = xmldoc.getElementsByTagName('JOBS_WINDOWS')

#print 'Job Name; Report and Variant;'
for job in jobs:
    jobname = job.attributes['name'].value
    login = job.getElementsByTagName('ATTR_JOBS')[0].getElementsByTagName('Login')[0].firstChild.data
    workdir = job.getElementsByTagName('ATTR_WINDOWS')[0].getElementsByTagName('WorkingDirectory')[0].firstChild.data
    script = job.getElementsByTagName('SCRIPT')[0].getElementsByTagName('MSCRI')[0].firstChild.data
    script = script.replace("\n","<nl>")
    print '{jobname}; {login}; {workdir}; {script};'.format(jobname=jobname, login=login, workdir=workdir, script=script)
